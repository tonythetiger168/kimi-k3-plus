"""K3+ v3.0 Test Suite"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent.parent/"src"))
import torch
from configs import ultra_config, pro_config, lite_config, nano_config
from model import KimiK3Plus
from attention import KimiDeltaAttention
from moe import StableLatentMoE
from speculative_decoding import DraftModel, SpeculativeDecoder
from rag import RAGModule
from cot_compiler import CoTCompiler
from reasoning_budget import ReasoningBudgetController
from agentic import AgenticLayer
from memory import LongTermMemory

def test_sizes():
    for name,cfg in [("ultra",ultra_config),("pro",pro_config),("lite",lite_config),("nano",nano_config)]:
        m=KimiK3Plus(cfg,size=name); print(f"  {name.upper()}: {sum(p.numel() for p in m.parameters()):,} params")
    print("✅ 4 sizes OK")

def test_forward():
    m=KimiK3Plus(lite_config,size="lite")
    ids=torch.randint(0,lite_config.vocab_size,(2,128))
    logits,aux=m(ids)
    assert logits.shape==(2,128,lite_config.vocab_size) and aux>=0
    print("✅ Forward OK")

def test_speculative():
    m=KimiK3Plus(lite_config,size="lite")
    draft=DraftModel(lite_config)
    dec=SpeculativeDecoder(m,draft,lite_config)
    ids=torch.randint(0,lite_config.vocab_size,(1,10))
    out,rate,speed=dec.generate(ids,20)
    assert out.shape[1]>ids.shape[1]
    print(f"✅ Speculative OK (rate:{rate:.2f}, speed:{speed:.1f})")

def test_rag():
    rag=RAGModule(lite_config)
    h=torch.randn(2,10,lite_config.hidden_size)
    out=rag(h)
    assert "confidence" in out
    print("✅ RAG OK")

def test_cot():
    cot=CoTCompiler(lite_config)
    h=torch.randn(1,10,lite_config.hidden_size)
    out=cot.compile_reasoning(h)
    assert "max_steps" in out
    print("✅ CoT OK")

def test_budget():
    rb=ReasoningBudgetController(lite_config)
    h=torch.randn(1,10,lite_config.hidden_size)
    budget,diff=rb.get_budget(h,4096)
    assert budget>0
    print(f"✅ Budget OK (budget:{budget}, diff:{diff})")

def test_agentic():
    a=AgenticLayer(lite_config)
    h=torch.randn(1,10,lite_config.hidden_size)
    out=a(h)
    assert "tools" in out
    print("✅ Agentic OK")

def test_memory():
    mem=LongTermMemory(lite_config)
    k=torch.randn(lite_config.hidden_size)
    v=torch.randn(100,lite_config.hidden_size)
    mem.add(k,v,1.5)
    r=mem.retrieve(k,3)
    assert len(r)>0
    print("✅ Memory OK")

if __name__=="__main__":
    print("🧪 K3+ v3.0 Test Suite"); print("="*40)
    test_sizes(); test_forward(); test_speculative(); test_rag(); test_cot(); test_budget(); test_agentic(); test_memory()
    print("="*40+"\n🎉 All tests passed!")
