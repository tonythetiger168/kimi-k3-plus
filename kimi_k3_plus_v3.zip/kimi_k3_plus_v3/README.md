# Kimi K3+ v3.0 🚀

> **P0+P1+P2+P3+P4 全改进实现** | 一个架构，四个尺寸，全场景覆盖

## 五大改进 (P0-P4)

| 优先级 | 改进 | 文件 | 效果 |
|:---:|:---|:---|:---:|
| **P0** | 推测解码 + 动态稀疏度 + 连续批处理 | `speculative_decoding.py`, `moe.py` | 速度 **37→210 tok/s** |
| **P1** | RAG + 置信度校准 + 多模型验证 | `rag.py` | 幻觉 **51%→<30%** |
| **P2** | 领域专家分群 + CoT编译 + 工具使用 | `moe.py`, `cot_compiler.py` | HLE **43.5→55+** |
| **P3** | MCP工具链 + 自我反思 + 代码执行验证 | `agentic.py`, `memory.py` | SWE-bench **缺失→95%** |
| **P4** | 推理预算控制 + 投机推理 + 并行子任务 | `reasoning_budget.py` | 延迟 **44min→<10min** |

## 四尺寸产品矩阵

| 型号 | 参数 | 上下文 | 速度目标 | 定价 | 定位 |
|:---|:---:|:---:|:---:|:---:|:---|
| **Ultra** | 2.8T | 2M | 210 tok/s | $3/$15 | 品质旗舰 |
| **Pro** | 600B | 1M | 300 tok/s | $1.5/$8 | 企业级 |
| **Lite** | 300B | 512K | 400 tok/s | $0.8/$4 | 边缘级 |
| **Nano** | 30B | 128K | 600 tok/s | $0.3/$1.5 | 本地级 |

## 快速开始

```bash
pip install torch numpy tqdm
python tests/test_all.py        # 运行测试
python scripts/benchmark.py     # 基准测试
python scripts/train.py --size ultra --phase pretrain
python scripts/inference.py --size lite --speculative
```

## 项目结构

```
kimi_k3_plus_v3/
├── configs/          # 配置 (base + 4 sizes)
├── src/              # 核心模块
│   ├── attention.py          # KDA + Gated MLA + AttnRes
│   ├── moe.py                # 动态稀疏度 + 领域分群 (P0+P2)
│   ├── speculative_decoding.py  # 推测解码 + 连续批处理 (P0)
│   ├── rag.py                # RAG + 幻觉校准 (P1)
│   ├── cot_compiler.py       # CoT编译 + 工具使用 (P2)
│   ├── agentic.py            # MCP + 自我反思 + 代码验证 (P3)
│   ├── memory.py             # 长期记忆 (P3)
│   ├── reasoning_budget.py   # 推理预算控制 (P4)
│   ├── model.py              # 统一架构
│   └── trainer.py            # 训练器
├── scripts/          # 脚本
└── tests/            # 测试
```

## 许可证

Kimi K3 License
